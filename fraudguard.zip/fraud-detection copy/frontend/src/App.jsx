import { useState } from "react";
import "./App.css";

function App() {
 const [url, setUrl] = useState("");
 const [scanResult, setScanResult] = useState(null);
 

const handleScan = async (e) => {
  e.preventDefault();

  if (!url.trim()) {
    alert("Please enter a website URL.");
    return;
  }

  try {
  
    const response = await fetch("http://localhost:5000/api/scan", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: url.trim(),
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Scan failed");
    }

  console.log("Scan result:", data);

setScanResult(data.result);
 } catch (error) {
  console.error("Scan error:", error);
  alert("Could not connect to the fraud detection server.");
}
};

  return (
    <div className="app">
      <nav className="navbar">
        <div className="logo">
          <span className="shield">🛡️</span>
          FraudGuard
        </div>

        <div className="nav-links">
          <a href="#how-it-works">How it works</a>
          <a href="#about">About</a>
        </div>
      </nav>

      <main className="hero">
        <div className="badge">🛡️ AI-POWERED WEBSITE SECURITY</div>

        <h1>
          Is this website
          <br />
          <span>safe or a scam?</span>
        </h1>

        <p className="subtitle">
          Check a website for suspicious signals and understand the
          evidence behind its risk assessment.
        </p>

        <form className="scan-box" onSubmit={handleScan}>
          <div className="url-input-wrapper">
            <span className="globe">🌐</span>

            <input
              type="text"
              placeholder="Enter website URL..."
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
          </div>

         <button type="submit">
  Scan Website
  <span>→</span>
</button>
        </form>
{scanResult && (
  <div className="scan-result">
    <h2>Scan Result</h2>

    <p>
      <strong>Website:</strong> {scanResult.url}
    </p>

   <p>
  <strong>Risk:</strong>{" "}
  <span className={`risk-badge ${scanResult.risk.toLowerCase()}`}>
    {scanResult.risk}
  </span>
</p>

    <p>
      <strong>Score:</strong> {scanResult.score}/100
    </p>

    <h3>Evidence</h3>

    {scanResult.indicators.length === 0 ? (
      <p>No suspicious indicators detected.</p>
    ) : (
      <ul>
        {scanResult.indicators.map((indicator, index) => (
          <li key={index}>
            <strong>{indicator.severity.toUpperCase()}</strong>:{" "}
            {indicator.message}
          </li>
        ))}
      </ul>
    )}
  </div>
)}
        <p className="privacy">
          🔒 We analyze the URL and security signals. Never enter passwords
          or sensitive information.
        </p>

        <div className="features">
          <div className="feature">
            <div className="feature-icon">🔍</div>
            <h3>Website Analysis</h3>
            <p>Analyze URL and website security signals.</p>
          </div>

          <div className="feature">
            <div className="feature-icon">📊</div>
            <h3>Risk Assessment</h3>
            <p>See risk indicators and supporting evidence.</p>
          </div>

          <div className="feature">
            <div className="feature-icon">🤖</div>
            <h3>AI Explanation</h3>
            <p>Get a simple explanation of the findings.</p>
          </div>
        </div>
      </main>

      <section id="how-it-works" className="how-it-works">
        <h2>How it works</h2>

        <div className="steps">
          <div>
            <span>01</span>
            <h3>Enter a URL</h3>
            <p>Paste the website address you want to check.</p>
          </div>

          <div>
            <span>02</span>
            <h3>We analyze it</h3>
            <p>Multiple technical signals are examined.</p>
          </div>

          <div>
            <span>03</span>
            <h3>Understand the result</h3>
            <p>Review the risk assessment and evidence.</p>
          </div>
        </div>        
      </section>
    </div>
  );
}

export default App;