function analyzeUrl(inputUrl) {
  const indicators = [];

  let parsedUrl;

  try {
    parsedUrl = new URL(inputUrl);
  } catch {
    return {
      valid: false,
      score: 100,
      indicators: [
        {
          type: "invalid-url",
          severity: "high",
          message: "The supplied URL is not valid.",
        },
      ],
    };
  }

  // HTTPS check
  if (parsedUrl.protocol !== "https:") {
    indicators.push({
      type: "no-https",
      severity: "medium",
      message: "The website does not use HTTPS.",
    });
  }

  // IP address check
  const ipPattern =
    /^(?:\d{1,3}\.){3}\d{1,3}$/;

  if (ipPattern.test(parsedUrl.hostname)) {
    indicators.push({
      type: "ip-address",
      severity: "high",
      message: "The URL uses an IP address instead of a domain name.",
    });
  }

  // Very long URL
  if (inputUrl.length > 150) {
    indicators.push({
      type: "long-url",
      severity: "low",
      message: "The URL is unusually long.",
    });
  }

  // Suspicious URL characters
  if (inputUrl.includes("@")) {
    indicators.push({
      type: "at-symbol",
      severity: "medium",
      message: "The URL contains an @ symbol.",
    });
  }

  // Suspicious keywords
  const suspiciousKeywords = [
    "verify-account",
    "verify-account-now",
    "secure-login",
    "account-suspended",
    "confirm-payment",
    "urgent",
  ];

  const lowerUrl = inputUrl.toLowerCase();

  const foundKeywords = suspiciousKeywords.filter((keyword) =>
    lowerUrl.includes(keyword)
  );

  if (foundKeywords.length > 0) {
    indicators.push({
      type: "suspicious-keywords",
      severity: "medium",
      message: `Potentially suspicious keywords detected: ${foundKeywords.join(
        ", "
      )}.`,
    });
  }

  // Multiple subdomains
  const hostnameParts = parsedUrl.hostname.split(".");

  if (hostnameParts.length >= 5) {
    indicators.push({
      type: "many-subdomains",
      severity: "medium",
      message: "The hostname contains an unusually large number of subdomains.",
    });
  }

  // Basic score
  let score = 0;

  for (const indicator of indicators) {
    if (indicator.severity === "high") {
      score += 35;
    } else if (indicator.severity === "medium") {
      score += 20;
    } else {
      score += 10;
    }
  }

  score = Math.min(score, 100);

  let risk = "LOW";

  if (score >= 60) {
    risk = "HIGH";
  } else if (score >= 30) {
    risk = "SUSPICIOUS";
  }

  return {
    valid: true,
    url: inputUrl,
    hostname: parsedUrl.hostname,
    protocol: parsedUrl.protocol,
    score,
    risk,
    indicators,
  };
}

module.exports = {
  analyzeUrl,
};
