const express = require("express");
const cors = require("cors");
require("dotenv").config();

const { analyzeUrl } = require("./src/urlAnalyzer");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    message: "Fraud Detection API is running!",
  });
});

app.get("/api/health", (req, res) => {
  res.json({
    status: "OK",
    message: "Backend is healthy",
  });
});
app.post("/api/scan", (req, res) => {
  const { url } = req.body;

  if (!url) {
    return res.status(400).json({
      success: false,
      message: "URL is required",
    });
  }

  console.log(`🔍 Scanning: ${url}`);

  const result = analyzeUrl(url);

  res.json({
    success: true,
    message: "URL analyzed successfully",
    result,
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Backend running at http://localhost:${PORT}`);
});